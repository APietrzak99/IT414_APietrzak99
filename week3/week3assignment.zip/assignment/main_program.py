from functions.filesystem_functions import unzipFile
from functions.filesystem_functions import readLogs
from functions.filesystem_functions import renameFile
from functions.filesystem_functions import deleteFile
from functions.filesystem_functions import final_zip

unzipFile()

readLogs()

deleteFile()

renameFile()

final_zip()

print("Log Reading Complete")